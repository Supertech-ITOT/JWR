/** @type {import('next').NextConfig} */
const nextConfig = {
  reactCompiler: false,
  devIndicators: false
};

export default nextConfig;
