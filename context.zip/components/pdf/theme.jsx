export const THEME = {
    main: "#3dcd58",
    bg: "#ffffff",
    txt: "#1f1f1f",
    card: "#fdffff",
    border: "#e0e3e5",
    shadow: "#C4C9CF",
    evenbg: "#eeebf0"
};